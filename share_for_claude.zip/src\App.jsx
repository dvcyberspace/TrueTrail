import { useState, useEffect, useRef } from "react";
import "./App.css";
import {
  MapContainer,
  TileLayer,
  Marker,
  Popup,
  Polyline,
} from "react-leaflet";
import "leaflet/dist/leaflet.css";
import ForceGraph2D from "react-force-graph-2d";
import ReactLenis from "lenis/react";
import { RippleBackground } from "./RippleBackground";
import { SkiperText } from "./SkiperText";
import L from "leaflet";

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
  iconUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
  shadowUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
});

const buildGraphData = (transactions) => {
  const topTxns = [...transactions]
    .sort((a, b) => b.amount - a.amount)
    .slice(0, 50);
  const nodesMap = new Map();
  const links = [];
  topTxns.forEach((txn) => {
    const senderId = txn.sender_account || txn.sender_vpa || txn.sender_name;
    const receiverId =
      txn.receiver_account || txn.receiver_vpa || txn.receiver_name;
    if (!senderId || !receiverId) return;
    if (!nodesMap.has(senderId))
      nodesMap.set(senderId, {
        id: senderId,
        name: txn.sender_name || senderId,
        group: "sender",
      });
    if (!nodesMap.has(receiverId))
      nodesMap.set(receiverId, {
        id: receiverId,
        name: txn.receiver_name || receiverId,
        group: "receiver",
      });
    links.push({ source: senderId, target: receiverId, value: txn.amount });
  });
  return { nodes: Array.from(nodesMap.values()), links };
};

function App() {
  const [auditLog, setAuditLog] = useState([]);
  const [chainStatus, setChainStatus] = useState(null);
  const [file, setFile] = useState(null);
  const [uploadStatus, setUploadStatus] = useState("");
  const [activeTab, setActiveTab] = useState("dashboard");
  const [timelineData, setTimelineData] = useState(null);
  const [graphData, setGraphData] = useState({ nodes: [], links: [] });

  const graphRef = useRef();

  useEffect(() => {
    import("./timeline.json")
      .then((data) => setTimelineData(data.default || data))
      .catch(() => {});
    import("./transactions.json")
      .then((data) => setGraphData(buildGraphData(data.default || data)))
      .catch(() => {});
  }, []);

  const fetchAudit = async () => {
    try {
      const res = await fetch("http://localhost:8001/audit");
      if (res.ok) {
        const data = await res.json();
        setAuditLog(data);
        const verifyRes = await fetch("http://localhost:8001/audit/verify");
        setChainStatus(await verifyRes.json());
      }
    } catch (err) {}
  };

  useEffect(() => {
    fetchAudit();
  }, []);

  const handleUpload = async () => {
    if (!file) return alert("Select a file!");
    const formData = new FormData();
    formData.append("file", file);
    try {
      setUploadStatus("Hashing...");
      const res = await fetch("http://localhost:8001/evidence/upload", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      setUploadStatus(`✅ Hash: ${data.sha256.substring(0, 15)}...`);
      fetchAudit();
    } catch (err) {
      setUploadStatus("❌ Backend not responding.");
    }
  };

  const getPathCoords = () => {
    if (!timelineData || !timelineData.geo_tracks) return [];
    const feature = timelineData.geo_tracks[0].geojson.features.find(
      (f) => f.properties.kind === "path",
    );
    return feature ? feature.geometry.coordinates.map((c) => [c[1], c[0]]) : [];
  };

  return (
    <ReactLenis root>
      <RippleBackground />
      <div
        className="app-container"
        style={{ position: "relative", zIndex: 1 }}
      >
        {/* FLOATING TOP-LEFT CARD */}
        <div className="sidebar">
          <h2
            style={{ color: "#fff", margin: "0 0 5px 0", letterSpacing: "2px" }}
          >
            TRUETRAIL
          </h2>
          <p
            style={{
              fontSize: "11px",
              color: "#666",
              margin: "0 0 20px 0",
              letterSpacing: "2px",
            }}
          >
            EVIDENCE ENGINE
          </p>

          <div
            style={{
              background: "#0a0a0a",
              padding: "15px",
              borderRadius: "8px",
              border: "1px solid #1a1a1a",
            }}
          >
            <h4
              style={{
                margin: "0 0 15px 0",
                color: "#ccc",
                fontSize: "12px",
                letterSpacing: "1px",
              }}
            >
              INGEST EVIDENCE
            </h4>
            <input
              type="file"
              onChange={(e) => setFile(e.target.files[0])}
              style={{ fontSize: "11px", marginBottom: "10px", color: "#888" }}
            />
            <button
              className="neon-btn"
              onClick={handleUpload}
              style={{ width: "100%" }}
            >
              Upload & Hash
            </button>
            {uploadStatus && (
              <p
                style={{
                  fontSize: "10px",
                  color: "#4ade80",
                  marginTop: "10px",
                  wordBreak: "break-all",
                }}
              >
                {uploadStatus}
              </p>
            )}
          </div>
        </div>

        <div className="main-content">
          {/* HERO SECTION (Gap reduced) */}
          <div
            style={{
              padding: "60px 0 20px 0",
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
            }}
          >
            <h1
              style={{
                fontSize: "3.5rem",
                margin: 0,
                lineHeight: "1.2",
                letterSpacing: "-1px",
                background: "linear-gradient(90deg, #fff, #888)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              Digital Evidence Correlation
            </h1>
            <p style={{ color: "#666", fontSize: "1.2rem", marginTop: "10px" }}>
              Secure. Correlate. Reconstruct.
            </p>
          </div>

          <SkiperText />

          <div
            style={{
              display: "flex",
              gap: "10px",
              marginBottom: "30px",
              position: "sticky",
              top: "20px",
              zIndex: 100,
            }}
          >
            {["dashboard", "graph", "timeline", "map"].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`tab-btn ${activeTab === tab ? "active" : ""}`}
                style={{ textTransform: "capitalize" }}
              >
                {tab}
              </button>
            ))}
          </div>

          {activeTab === "dashboard" && (
            <div className="panel neon-card">
              <h2 style={{ marginTop: 0, letterSpacing: "1px" }}>
                CHAIN OF CUSTODY
              </h2>
              <div
                style={{
                  padding: "15px",
                  background: chainStatus?.valid
                    ? "rgba(74, 222, 128, 0.05)"
                    : "rgba(248, 113, 113, 0.05)",
                  color: chainStatus?.valid ? "#4ade80" : "#f87171",
                  border: `1px solid ${chainStatus?.valid ? "rgba(74, 222, 128, 0.2)" : "rgba(248, 113, 113, 0.2)"}`,
                  borderRadius: "8px",
                  marginBottom: "20px",
                }}
              >
                <strong>Integrity Status: </strong>{" "}
                {chainStatus?.valid
                  ? `✅ SECURE (${chainStatus.entries} entries)`
                  : "❌ TAMPERED or OFFLINE"}
              </div>
              <table className="audit-table">
                <thead>
                  <tr>
                    <th>File</th>
                    <th>SHA-256 Hash</th>
                  </tr>
                </thead>
                <tbody>
                  {auditLog.map((row) => (
                    <tr key={row.id}>
                      <td>{row.file_name}</td>
                      <td style={{ fontFamily: "monospace", color: "#888" }}>
                        {row.file_hash}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {activeTab === "graph" && (
            <div
              className="panel neon-card"
              style={{ height: "700px", position: "relative", padding: 0 }}
            >
              <ForceGraph2D
                ref={graphRef}
                graphData={graphData}
                nodeAutoColorBy="group"
                linkDirectionalArrowLength={3.5}
                linkDirectionalArrowRelPos={1}
                linkColor={() => "rgba(255,255,255,0.1)"}
                linkWidth={(link) => Math.min(1 + Math.log(link.value || 1), 4)}
                backgroundColor="transparent"
                width={800}
                height={700}
                d3AlphaDecay={0.01}
                d3VelocityDecay={0.1}
                nodeCanvasObject={(node, ctx, globalScale) => {
                  const label = node.name;
                  const fontSize = 12 / globalScale;
                  ctx.font = `${fontSize}px Inter`;

                  ctx.beginPath();
                  ctx.arc(node.x, node.y, 5, 0, 2 * Math.PI, false);
                  ctx.fillStyle =
                    node.group === "sender" ? "#00ffcc" : "#ff3caa";
                  ctx.fill();
                  ctx.strokeStyle = "rgba(255,255,255,0.2)";
                  ctx.lineWidth = 1 / globalScale;
                  ctx.stroke();

                  ctx.textAlign = "center";
                  ctx.textBaseline = "middle";
                  ctx.fillStyle = "rgba(255,255,255,0.8)";
                  ctx.fillText(label, node.x, node.y + 12);
                }}
              />
            </div>
          )}

          {activeTab === "timeline" && timelineData && (
            <div className="panel neon-card">
              <h2 style={{ marginTop: 0, letterSpacing: "1px" }}>
                EVENT RECONSTRUCTION
              </h2>
              <div
                style={{
                  borderLeft: "2px solid #222",
                  paddingLeft: "20px",
                  marginTop: "20px",
                }}
              >
                {timelineData.events.map((evt) => (
                  <div
                    key={evt.event_id}
                    style={{ marginBottom: "20px", position: "relative" }}
                  >
                    <div
                      style={{
                        position: "absolute",
                        left: "-26px",
                        top: "5px",
                        width: "10px",
                        height: "10px",
                        borderRadius: "50%",
                        background: evt.type === "UPI" ? "#ff4d4d" : "#00ffcc",
                        boxShadow: `0 0 10px ${evt.type === "UPI" ? "#ff4d4d" : "#00ffcc"}`,
                      }}
                    ></div>
                    <div
                      style={{
                        fontSize: "11px",
                        color: "#555",
                        fontFamily: "monospace",
                      }}
                    >
                      {new Date(evt.start_utc).toLocaleString()}
                    </div>
                    <div
                      style={{
                        fontWeight: "bold",
                        color: "#fff",
                        margin: "4px 0",
                      }}
                    >
                      {evt.type} {evt.amount ? `- ₹${evt.amount}` : ""}
                    </div>
                    <div style={{ fontSize: "13px", color: "#888" }}>
                      {evt.type === "UPI"
                        ? `Paid to ${evt.entities.payee_id}`
                        : `Device: ${evt.entities.imei || "N/A"}`}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === "map" && timelineData && (
            <div
              className="panel neon-card"
              style={{ padding: 0, overflow: "hidden", height: "600px" }}
            >
              <MapContainer
                center={[28.753477, 77.057639]}
                zoom={12}
                style={{ height: "100%", width: "100%", background: "#000" }}
              >
                <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                <Polyline
                  pathOptions={{ color: "#00ffcc", weight: 3, opacity: 0.8 }}
                  positions={getPathCoords()}
                />
                {timelineData.geo_tracks[0].geojson.features
                  .filter((f) => f.properties.kind === "ping")
                  .map((ping, idx) => (
                    <Marker
                      key={idx}
                      position={[
                        ping.geometry.coordinates[1],
                        ping.geometry.coordinates[0],
                      ]}
                    >
                      <Popup>
                        {new Date(ping.properties.time_utc).toLocaleString()}
                      </Popup>
                    </Marker>
                  ))}
              </MapContainer>
            </div>
          )}
        </div>
      </div>
    </ReactLenis>
  );
}

export default App;
