import { useEffect, useState } from "react";

export const RippleBackground = () => {
  const [ripples, setRipples] = useState([]);

  useEffect(() => {
    // Auto-trigger a ripple every 5 seconds
    const interval = setInterval(() => {
      const x = Math.random() * window.innerWidth;
      const y = Math.random() * window.innerHeight;
      addRipple(x, y);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const addRipple = (e) => {
    const x = e.clientX || e;
    const y = e.clientY || e;
    const id = Date.now();
    setRipples((prev) => [...prev, { id, x, y }]);
    setTimeout(() => {
      setRipples((prev) => prev.filter((r) => r.id !== id));
    }, 2000);
  };

  return (
    <div
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100vw",
        height: "100vh",
        zIndex: -1,
        background: "#000",
        overflow: "hidden",
        cursor: "crosshair",
      }}
      onClick={addRipple}
    >
      {/* Grid Pattern */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)",
          backgroundSize: "50px 50px",
        }}
      />

      {/* Ripples */}
      {ripples.map((r) => (
        <div
          key={r.id}
          style={{
            position: "absolute",
            left: r.x,
            top: r.y,
            width: "10px",
            height: "10px",
            borderRadius: "50%",
            border: "1px solid rgba(0, 255, 204, 0.4)",
            boxShadow:
              "0 0 20px rgba(0, 255, 204, 0.2), inset 0 0 10px rgba(255, 60, 170, 0.2)",
            transform: "translate(-50%, -50%)",
            animation: "rippleAnim 2s ease-out forwards",
            pointerEvents: "none",
          }}
        />
      ))}
    </div>
  );
};
