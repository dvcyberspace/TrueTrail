import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";

const Character = ({ char, index, centerIndex, scrollYProgress }) => {
  const distanceFromCenter = index - centerIndex;
  const x = useTransform(
    scrollYProgress,
    [0, 0.5],
    [distanceFromCenter * 40, 0],
  );
  const rotateX = useTransform(
    scrollYProgress,
    [0, 0.5],
    [distanceFromCenter * 40, 0],
  );
  const opacity = useTransform(scrollYProgress, [0, 0.2, 1], [0, 1, 1]);

  return (
    <motion.span
      style={{
        display: "inline-block",
        x,
        rotateX,
        opacity,
        color: "#fff",
        textShadow: "0 0 10px rgba(0,255,204,0.3)",
      }}
    >
      {char === " " ? "\u00A0" : char}
    </motion.span>
  );
};

export const SkiperText = () => {
  const targetRef = useRef(null);
  const { scrollYProgress } = useScroll({ target: targetRef });

  const text = "DECODE THE EVIDENCE";
  const characters = text.split("");
  const centerIndex = Math.floor(characters.length / 2);

  return (
    /* Height 100vh kar diya taaki extra gap na bache */
    <div
      ref={targetRef}
      style={{
        height: "100vh",
        position: "relative",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        overflow: "hidden",
        marginTop: "-50px",
      }}
    >
      <div
        style={{
          position: "sticky",
          top: "40vh",
          textAlign: "center",
          width: "100%",
        }}
      >
        <div
          style={{
            fontSize: "3rem",
            fontWeight: "bold",
            perspective: "500px",
            letterSpacing: "0.1em",
            whiteSpace: "nowrap",
            display: "flex",
            justifyContent: "center",
          }}
        >
          {characters.map((char, index) => (
            <Character
              key={char + index}
              char={char}
              index={index}
              centerIndex={centerIndex}
              scrollYProgress={scrollYProgress}
            />
          ))}
        </div>
        <p style={{ color: "#555", fontSize: "12px", marginTop: "20px" }}>
          Scroll effect by Skiper UI
        </p>
      </div>
    </div>
  );
};
